// (jEdit options) :folding=explicit:collapseFolds=1:
//{{{ Package, imports
package chiropraxis.sc;

//import java.awt.*;
//import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;
//import java.util.regex.*;
//import javax.swing.*;
import driftwood.moldb2.*;
import driftwood.r3.*;
import driftwood.util.SoftLog;
//}}}
/**
* <code>SidechainIdealizer</code> is a class for working with
* ideal geometry side chains modeled in moldb2.
*
* <p>Copyright (C) 2003 by Ian W. Davis. All rights reserved.
* <br>Begun on Thu Mar 20 14:08:45 EST 2003
*/
public class SidechainIdealizer //extends ... implements ...
{
//{{{ Constants
//}}}

//{{{ Variable definitions
//##################################################################################################
    SidechainAngles2    scAngles;
    Map                 idealMap;
//}}}

//{{{ Constructor(s)
//##################################################################################################
    /**
    * Constructor
    */
    public SidechainIdealizer() throws IOException
    {
        scAngles = new SidechainAngles2();
        idealMap = loadIdealGeom();
    }
//}}}

//{{{ loadIdealGeom
//##################################################################################################
    /**
    * Opens a PDB of ideal geometry sc from the JAR, and enters coords in the table.
    * Coordinates are translated so that the C-alpha is at (0,0,0).
    * @throws AtomException if any atoms are missing coordinates,
    *   which should never happen with the input we're providing.
    * @return Map&lt;Residue.getName(), Map&lt;Atom.getName(), Triple&gt;&gt;
    */
    Map loadIdealGeom() throws IOException
    {
        InputStream is = this.getClass().getResourceAsStream("singlesc.pdb");
        if(is == null) throw new IOException("File not found in JAR: singlesc.pdb");
        
        PdbReader   pdbr    = new PdbReader();
        ModelGroup  mg      = pdbr.read(is);
        Model       m       = mg.getFirstModel();
        ModelState  s       = m.getState();
        
        Map rmap = new HashMap();
        for(Iterator ri = m.getResidues().iterator(); ri.hasNext(); )
        {
            Residue     res     = (Residue)ri.next();
            AtomState   ca      = s.get( res.getAtom(" CA ") );
            Map         amap    = new HashMap();
            for(Iterator ai = res.getAtoms().iterator(); ai.hasNext(); )
            {
                Atom        a   = (Atom)ai.next();
                AtomState   as  = s.get(a);
                amap.put(a.getName(), new Triple(as).sub(ca));
            }
            rmap.put(res.getName(), amap);
        }
        return rmap;
    }
//}}}

//{{{ idealizeCB
//##################################################################################################
    /**
    * Given a heavy-atom backbone (N, CA, C)
    * this will reconstruct the C-beta and H-alpha(s)
    * if they already exist.
    * The existing sidechain will be rotated about the C-alpha
    * to bring it into the correct position.
    *
    * The reconstruction is fully generic and is not
    * adjusted for the type of residue under consideration.
    * Only bond angles (not lengths) are altered.
    *
    * @return a new state, descended from orig, which contains
    *   new states for all non-mainchain atoms.
    * @throws ResidueException if any of the required backbone atoms
    *   (N, CA, C) are missing.
    */
    public static ModelState idealizeCB(Residue res, ModelState orig)
    {
        Triple t1, t2, ideal = new Triple();
        Builder build = new Builder();
        ModelState modState = new ModelState(orig);
        
        try // looking for AtomExceptions when states are missing
        {
            // These will trigger AtomExceptions if res is missing an Atom
            // because it will try to retrieve the state of null.
            AtomState aaN   = orig.get( res.getAtom(" N  ") );
            AtomState aaCA  = orig.get( res.getAtom(" CA ") );
            AtomState aaC   = orig.get( res.getAtom(" C  ") );
            
            // Build an ideal C-beta and swing the side chain into place
            Atom cBeta = res.getAtom(" CB ");
            if(cBeta != null)
            {
                // Construct ideal C-beta
                t1 = build.construct4(aaN, aaC, aaCA, 1.536, 110.4, 123.1);
                t2 = build.construct4(aaC, aaN, aaCA, 1.536, 110.6, -123.0);
                ideal.likeMidpoint(t1, t2);
                
                // Construct rotation to align actual and ideal
                AtomState aaCB = orig.get(cBeta);
                double theta = Triple.angle(ideal, aaCA, aaCB);
                //SoftLog.err.println("Angle of correction: "+theta);
                t1.likeNormal(ideal, aaCA, aaCB).add(aaCA);
                Transform xform = new Transform().likeRotation(aaCA, t1, theta);
                
                // Apply the transformation
                for(Iterator iter = res.getAtoms().iterator(); iter.hasNext(); )
                {
                    Atom        atom    = (Atom)iter.next();
                    String      name    = atom.getName();
                    
                    // Transform everything that's not mainchain
                    if( !( name.equals(" N  ") || name.equals(" H  ")
                        || name.equals(" CA ") || name.equals(" HA ")
                        || name.equals("1HA ") || name.equals("2HA ")
                        || name.equals(" C  ") || name.equals(" O  ")) )
                    {
                        // Clone the original state, move it, and insert it into our model
                        AtomState   s1      = orig.get(atom);
                        AtomState   s2      = (AtomState)s1.clone();
                        xform.transform(s1, s2);
                        modState.add(s2);
                    }//if atom is not mainchain
                }//for each atom in the residue
            }//rebuilt C-beta
            
            
            // Reconstruct alpha hydrogens
            // These are easier -- just compute the position and make it so!
            Atom hAlpha = res.getAtom(" HA ");
            if(hAlpha != null)
            {
                AtomState s1 = orig.get(hAlpha);
                AtomState s2 = (AtomState)s1.clone();
                t1 = build.construct4(aaN, aaC, aaCA, 1.100, 107.9, -118.3);
                t2 = build.construct4(aaC, aaN, aaCA, 1.100, 108.1, 118.2);
                s2.likeMidpoint(t1, t2).sub(aaCA).unit().mult(1.100).add(aaCA);
                modState.add(s2);
            }
            
            // Now for glycine, and then we're done
            hAlpha = res.getAtom("1HA ");
            if(hAlpha != null)
            {
                AtomState s1 = orig.get(hAlpha);
                AtomState s2 = (AtomState)s1.clone();
                t1 = build.construct4(aaN, aaC, aaCA, 1.100, 109.3, -121.6);
                t2 = build.construct4(aaC, aaN, aaCA, 1.100, 109.3, 121.6);
                s2.likeMidpoint(t1, t2).sub(aaCA).unit().mult(1.100).add(aaCA);
                modState.add(s2);
            }
            hAlpha = res.getAtom("2HA ");
            if(hAlpha != null)
            {
                AtomState s1 = orig.get(hAlpha);
                AtomState s2 = (AtomState)s1.clone();
                t1 = build.construct4(aaN, aaC, aaCA, 1.100, 109.3, 121.6);
                t2 = build.construct4(aaC, aaN, aaCA, 1.100, 109.3, -121.6);
                s2.likeMidpoint(t1, t2).sub(aaCA).unit().mult(1.100).add(aaCA);
                modState.add(s2);
            }
        }
        catch(AtomException ex)
        { throw new ResidueException("C-beta idealize failed: "+ex.getMessage()); }
        
        return modState;
    }
//}}}

//{{{ idealizeSidechain
//##################################################################################################
    /**
    * Idealizes all aspects of sidechain geometry (bond lengths and angles).
    * Dihedrals are preserved from the original model.
    * All heavy atoms must be present, but H's are optional.
    * This method will not create missing atoms, only move existing ones.
    * It returns <code>start</code> if the residue is of unknown type.
    */
    public ModelState idealizeSidechain(Residue res, ModelState start)
    {
        Map atomMap = (Map)idealMap.get(res.getName());
        if(atomMap == null) // a residue we don't recognize
            return start;
        
        // Save initial conformation. Chis only b/c we might lack H's.
        double[] chis = scAngles.measureChiAngles(res, start);
        
        // This step corrects bond lengths and angles,
        // but leaves Ca-Cb oriented randomly.
        ModelState  end = new ModelState(start);
        AtomState   ca  = start.get( res.getAtom(" CA ") );
        for(Iterator iter = res.getAtoms().iterator(); iter.hasNext(); )
        {
            Atom    a   = (Atom)iter.next();
            Triple  t   = (Triple)atomMap.get(a.getName());
            if(t != null) // we have coords for this atom
            {
                AtomState   s1  = start.get(a);
                AtomState   s2  = (AtomState)s1.clone();
                s2.like(t).add(ca); // t has Ca at 0,0,0
                end.add(s2);
            }
        }
        
        // This step corrects Ca-Cb orientation.
        end = idealizeCB(res, end);
        
        // Restore original orientation (chi angles)
        end = scAngles.setChiAngles(res, end, chis);
        
        return end;
    }
//}}}

//{{{ empty_code_segment
//##################################################################################################
//}}}

//{{{ empty_code_segment
//##################################################################################################
//}}}
}//class

