// (jEdit options) :folding=explicit:collapseFolds=1:
//{{{ Package, imports
package driftwood.moldb2;

//import java.awt.*;
//import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;
//import java.util.regex.*;
//import javax.swing.*;
//import driftwood.*;
//}}}
/**
* <code>ModelGroup</code> is a lightweight container for a group
* of Models that have some relationship to one another.
*
* <p>Copyright (C) 2003 by Ian W. Davis. All rights reserved.
* <br>Begun on Wed Jun 11 11:15:15 EDT 2003
*/
public class ModelGroup //extends ... implements ...
{
//{{{ Constants
//}}}

//{{{ Variable definitions
//##################################################################################################
    /** The collection of Models that belong to this group */
    ArrayList           models;
    Collection          unmodModels     = null;
    ArrayList           headers;
    Collection          unmodHeaders    = null;
//}}}

//{{{ Constructor(s)
//##################################################################################################
    /**
    * Constructor
    */
    public ModelGroup()
    {
        models  = new ArrayList();
        headers = new ArrayList();
    }
//}}}

//{{{ getModels, getFirstModel
//##################################################################################################
    /** Returns an unmodifiable view of the models in this group */
    public Collection getModels()
    {
        if(unmodModels == null)
            unmodModels = Collections.unmodifiableCollection(models);
        return unmodModels;
    }
    
    /**
    * Returns the first model.
    * @throws NoSuchElementException if no models are present.
    */
    public Model getFirstModel()
    {
        Iterator iter = models.iterator();
        return (Model)iter.next();
    }
//}}}

//{{{ add
//##################################################################################################
    /** Adds a model to this group */
    public void add(Model m)
    {
        if(m == null) throw new NullPointerException("Cannot add a null model");
        models.add(m);
    }
    
    /** Replaces one model with another, or just adds the new model if the old one wasn't present. */
    public void replace(Model oldModel, Model newModel)
    {
        if(newModel == null) throw new NullPointerException("Cannot add a null model");
        
        int idx = models.indexOf(oldModel);
        if(idx == -1)   models.add(newModel);
        else            models.set(idx, newModel);
    }
//}}}

//{{{ addHeader, getHeaders
//##################################################################################################
    /**
    * Adds a line of header information to the list of data
    * associated with this group of models.
    * @param section    which block of info this line belongs in.
    * @param header     the actual header data.
    */
    public void addHeader(String section, String header)
    {
        // section may be used in the future
        // right now, it's ignored
        headers.add(header);
    }
    
    /** Returns an unmodifiable view of all the headers in this group */
    public Collection getHeaders()
    {
        if(unmodHeaders == null)
            unmodHeaders = Collections.unmodifiableCollection(headers);
        return unmodHeaders;
    }
//}}}

//{{{ empty_code_segment
//##################################################################################################
//}}}

//{{{ empty_code_segment
//##################################################################################################
//}}}
}//class

