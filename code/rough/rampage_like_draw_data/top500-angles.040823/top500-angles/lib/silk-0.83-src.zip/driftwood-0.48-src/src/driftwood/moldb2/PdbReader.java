// (jEdit options) :folding=explicit:collapseFolds=1:
//{{{ Package, imports
package driftwood.moldb2;

//import java.awt.*;
//import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;
//import java.util.regex.*;
//import javax.swing.*;
import driftwood.util.*;
//}}}
/**
* <code>PdbReader</code> is a utility class for loading Models
* from PDB-format files.
*
* <p>PdbReader and PdbWriter fail to deal with the following kinds of records:
* <ul>  <li>SIGATM</li>
*       <li>ANISOU</li>
*       <li>SIGUIJ</li>
*       <li>CONECT</li> </ul>
* <p>Actually, PdbReader puts all of them in with the headers, and
* PdbWriter spits them all back out, but it may not put them in the
* right part of the file.
*
* <p>Copyright (C) 2003 by Ian W. Davis. All rights reserved.
* <br>Begun on Wed Jun 11 11:15:15 EDT 2003
*/
public class PdbReader //extends ... implements ...
{
//{{{ Constants
//}}}

//{{{ Variable definitions
//##################################################################################################
    // Shared data structures
    
    /** The group of Models */
    ModelGroup  group;
    
    /** The current Model */
    Model       model;
    
    /** A Map&lt;String, Residue&gt; based on PDB naming */
    Map         residues;
    
    /** A surrogate atom serial number if necessary */
    int         autoSerial;
    
    /** If true, drop leading and trailing whitespace from seg IDs */
    boolean     trimSegID       = false;
    /** If true, segment IDs will define chains and thus must be consistent within one residue. */
    boolean     useSegID        = false;
//}}}

//{{{ Constructor(s)
//##################################################################################################
    /**
    * Constructor
    */
    public PdbReader()
    {
        clearData();
    }
//}}}

//{{{ init/clearData
//##################################################################################################
    void initData()
    {
        group       = new ModelGroup();
        model       = null;
        residues    = new HashMap();
        autoSerial  = -9999;
    }
    
    void clearData()
    {
        group       = null;
        model       = null;
        residues    = null;
        autoSerial  = -9999;
    }
//}}}

//{{{ read (convenience)
//##################################################################################################
    public ModelGroup read(File f) throws IOException
    {
        Reader r = new FileReader(f);
        ModelGroup rv = read(r);
        r.close();
        return rv;
    }

    public ModelGroup read(InputStream is) throws IOException
    {
        return read(new InputStreamReader(is));
    }

    public ModelGroup read(Reader r) throws IOException
    {
        return read(new LineNumberReader(r));
    }
//}}}

//{{{ read
//##################################################################################################
    /**
    * Reads a PDB file from a stream and extracts atom names and coordinates,
    * residue order, etc.
    * @param r a <code>LineNumberReader</code> hooked up to a PDB file
    */
    public ModelGroup read(LineNumberReader r) throws IOException
    {
        initData();
        
        String s;
        while((s = r.readLine()) != null)
        {
            try
            {
                if(s.startsWith("ATOM  ") || s.startsWith("HETATM"))
                {
                    readAtom(s);
                }
                else if(s.startsWith("MODEL ") && s.length() >= 14)
                {
                    model = new Model(s.substring(10,14).trim());
                    group.add(model);
                    residues.clear();
                }
                else if(s.startsWith("ENDMDL"))
                {
                    model = null;
                }
                else if(s.startsWith("TER") || s.startsWith("MASTER") || s.startsWith("END"))
                {
                    // These lines are useless. Ignore them.
                }
                else // headers
                {
                    // Headers are just saved for later and then output again
                    String six;
                    if(s.length() >= 6) six = s.substring(0,6);
                    else                six = s;
                    group.addHeader(six, s);
                }
            }
            catch(IndexOutOfBoundsException ex)
            { SoftLog.err.println("Error reading from PDB file, line "+r.getLineNumber()+": "+ex.getMessage()); }
            catch(NumberFormatException ex)
            { SoftLog.err.println("Error reading from PDB file, line "+r.getLineNumber()+": "+ex.getMessage()); }
        }//while more lines
        
        ModelGroup rv = group;
        clearData();
        return rv;
    }
//}}}

//{{{ readAtom
//##################################################################################################
    void readAtom(String s) throws NumberFormatException
    {
        checkModel();
        Residue r = makeResidue(s);
        Atom    a = makeAtom(r, s);
        
        int serialNum;
        String serial = s.substring(6, 11).trim();
        if(serial.length() > 0) serialNum = Integer.parseInt(serial);
        else                    serialNum = autoSerial++;
        
        AtomState state = new AtomState(a, serialNum);
        char altConf = s.charAt(16);
        state.setAltConf(altConf);
        
        // We're now ready to add this to a ModelState
        // It's possible this state will have no coords, etc
        ModelState mState = model.makeState(altConf);
        // This protects us against duplicate lines
        // that re-define the same atom and state!
        try { mState.add(state); }
        catch(AtomException ex) { SoftLog.err.println(ex.getMessage()); }
        
        double x, y, z;
        x = Double.parseDouble(s.substring(30, 38).trim());
        y = Double.parseDouble(s.substring(38, 46).trim());
        z = Double.parseDouble(s.substring(46, 54).trim());
        state.setXYZ(x, y, z);
        
        if(s.length() >= 60)
        {
            String q = s.substring(54, 60).trim();
            if(q.length() > 0) state.setOccupancy(Double.parseDouble(q));
        }
        if(s.length() >= 66)
        {
            String b = s.substring(60, 66).trim();
            if(b.length() > 0) state.setTempFactor(Double.parseDouble(b));
        }
        if(s.length() >= 80 && s.charAt(78) != ' ')
        {
            // These are formatted as 2+, 1-, etc.
            if(s.charAt(79) == '-')         state.setCharge('0' - s.charAt(78));
            else if(s.charAt(79) == '+')    state.setCharge(s.charAt(78) - '0');
            // else do nothing -- sometimes this field is used for other purposes (?)
        }
    }
//}}}

//{{{ checkModel, makeResidue
//##################################################################################################
    /** Makes sure that a model exists for things to go into */
    void checkModel()
    {
        if(model == null)
        {
            model = new Model("1");
            group.add(model);
            residues.clear();
        }
    }
    
    /** Retrieves a residue, creating it if necessary */
    Residue makeResidue(String s) throws NumberFormatException
    {
        checkModel();
        
        // Always pretend there is a fully space-padded field
        // present, because lines may be different lengths.
        String segID = "    ";
        if(s.length() > 72)
        {
            if(s.length() >= 76)    segID = s.substring(72,76);
            else                    segID = Strings.justifyLeft(s.substring(72), 4);
        }
        
        String key = s.substring(17,27);
        if(useSegID) key += segID;
        Residue r = (Residue)residues.get(key);
        
        if(r == null)
        {
            if(trimSegID) segID = segID.trim();
            int     seqNum  = Integer.parseInt(s.substring(22,26).trim());
            char    insCode = s.charAt(26);
            String  resName = s.substring(17,20);
            r = new Residue(s.charAt(21), segID, seqNum, insCode, resName);
            residues.put(key, r);
            model.add(r);
        }
        
        return r;
    }
//}}}

//{{{ makeAtom
//##################################################################################################
    /**
    * Returns the named atom from the given (non-null)
    * Residue, or creates it if it doesn't exist yet.
    */
    Atom makeAtom(Residue r, String s)
    {
        String  id  = s.substring(12, 16);
        Atom    a   = r.getAtom(id);
        if(a == null)
        {
            a = new Atom(id, s.startsWith("HETATM"));
            r.add(a);
        }
        return a;
    }
//}}}

//{{{ setUseSegID
//##################################################################################################
    /**
    * Determines whether or not segment IDs determine resiude identity;
    * i.e., whether otherwise identical residue specifications with
    * different segIDs will be treated as being the same or different.
    * In most cases, this should be left at its default value of <code>false</code>.
    * However, for structures without chain IDs but with multiple chains
    * (e.g. structures coming out of CNS refinement) it should be <code>true</code>.
    */
    public void setUseSegID(boolean b)
    { useSegID = b; }
//}}}

//{{{ empty_code_segment
//##################################################################################################
//}}}
}//class

